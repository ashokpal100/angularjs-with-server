A Pen created at CodePen.io. You can find this one at http://codepen.io/rickyeckhardt/pen/xrLCm.

 Login modal in haml and css. This was a 20 minute pen.